# Billogram Webhook (Vercel)

Detta projekt tar emot betalningsnotiser från Billogram och skickar ett mejl via Gmail.

## Miljövariabler (lägg i .env.local)

- EMAIL_USER=din.email@gmail.com
- EMAIL_PASS=ditt-applösenord
- NOTIFY_TO=mottagare@example.com

## Deploya

1. Forka detta repo till ditt GitHub-konto
2. Importera det till Vercel
3. Lägg in miljövariablerna
4. Klart!
